<?php
require_once '/var/private/auth.php';
$logfile = 'logs/recordings.log';
if (!file_exists($logfile)) {
    echo "Geen logs beschikbaar.";
    exit();
}

echo "<h1>Logs</h1>";
echo nl2br(file_get_contents($logfile));
