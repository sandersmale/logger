<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
// Indien je pagina's hebt die alleen toegankelijk moeten zijn voor admin-gebruikers,
// kun je hier extra controleren, bijvoorbeeld:
// if ($_SESSION['role'] !== 'admin') {
//     echo "Geen toegang.";
//     exit;
// }
?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
